from tqdm import tqdm

from django.core.management.base import BaseCommand

from recipes import models

PATH = 'data/'
INGREDIENTS = 'ingredients.csv'
UTF = 'UTF-8'
CHEK_LEN = 1


class Command(BaseCommand):
    def handle(self, **options):
        with open(f'{PATH}{INGREDIENTS}', encoding=UTF) as f:
            lines = f.readlines()
            for line in tqdm(lines,
                             desc='Загрузка ингредиентов', unit='ингредиент'
                             ):
                ing = line.strip().split(',')
                if len(ing) >= CHEK_LEN:
                    models.Ingredient.objects.get_or_create(
                        name=ing[0].strip(), measurement_unit=ing[1].strip()
                    )
