from django.core.validators import MinValueValidator
from django.db import transaction
from drf_extra_fields.fields import Base64ImageField
from rest_framework import serializers

from constants import MIN_VALUE
from recipes.models import (Favorite, Ingredient, IngredientRecipe, Recipe,
                            RecipeShortLink, ShoppingCart, Tag)
from users.serializers import UserSerializer


class TagSerializer(serializers.ModelSerializer):
    """Сериализатор Тегов."""

    class Meta:
        model = Tag
        fields = '__all__'


class IngredientSerializer(serializers.ModelSerializer):
    """Сериализатор ингредиентов."""

    class Meta:
        model = Ingredient
        fields = '__all__'


class RecipeIngredientSerializer(serializers.ModelSerializer):
    """Получение ингредиентов в рецепте."""

    id = serializers.IntegerField(source='ingredient.id')
    name = serializers.ReadOnlyField(source='ingredient.name')
    measurement_unit = serializers.ReadOnlyField(
        source='ingredient.measurement_unit'
    )

    class Meta:
        model = IngredientRecipe
        fields = ('id', 'name', 'measurement_unit', 'amount')


class RecipeGetSerializer(serializers.ModelSerializer):
    """Сериализатор для GET запросов по рецептам."""

    author = UserSerializer(read_only=True)
    image = Base64ImageField()
    ingredients = RecipeIngredientSerializer(
        many=True, source='recipe_ingredients'
    )
    tags = TagSerializer(many=True)
    is_favorited = serializers.SerializerMethodField()
    is_in_shopping_cart = serializers.SerializerMethodField()

    class Meta:
        model = Recipe
        fields = ('id', 'tags', 'author', 'ingredients',
                  'is_favorited', 'is_in_shopping_cart', 'name',
                  'image', 'text', 'cooking_time',)

    def get_is_favorited(self, obj):
        request = self.context.get('request')
        return (
            request.user.is_authenticated
            and obj.favorites.filter(user=request.user).exists()
        )

    def get_is_in_shopping_cart(self, obj):
        request = self.context.get('request')
        return (
            request.user.is_authenticated
            and obj.shoppingcarts.filter(user=request.user).exists()
        )


class IngredientAmountSerializer(serializers.ModelSerializer):
    """Сериализатор количества ингредиентов."""

    id = serializers.IntegerField(write_only=True)
    amount = serializers.IntegerField(
        write_only=True,
        validators=[MinValueValidator(
            MIN_VALUE, message=('Минимальное количество ингредиентов '
                                f'не может быть меньше {MIN_VALUE}'))]
    )

    class Meta:
        model = IngredientRecipe
        fields = ('id', 'amount')

    def validate_id(self, value):
        if not Ingredient.objects.filter(pk=value).exists():
            raise serializers.ValidationError(
                'Введен несуществующий ингредиент')
        return value


class RecipePostSerializer(serializers.ModelSerializer):
    """Сериализатор для POST запросов по рецептам."""

    author = UserSerializer(read_only=True)
    ingredients = IngredientAmountSerializer(many=True)
    tags = serializers.PrimaryKeyRelatedField(
        many=True, queryset=Tag.objects.all()
    )
    image = Base64ImageField()
    cooking_time = serializers.IntegerField(
        validators=[MinValueValidator(
            MIN_VALUE, message=('Минимальное время приготовления '
                                f'не может быть меньше {MIN_VALUE}'))]
    )

    class Meta:
        model = Recipe
        fields = '__all__'

    def to_representation(self, instance):
        """Представление данных."""
        serializer = RecipeGetSerializer(instance, context=self.context)
        return serializer.data

    def validate_image(self, value):
        """Дополнительная валидация поля image."""
        if not value:
            raise serializers.ValidationError(
                'Поле image не может быть пустым.'
            )
        return value

    def validate(self, data):
        """Метод валидации ингредиентов и тегов."""
        ingredients = data.get('ingredients', [])
        tags = data.get('tags', [])
        if not ingredients:
            raise serializers.ValidationError({
                'ingredients':
                'Должен быть хотя бы один ингредиент'}
            )
        if not tags:
            raise serializers.ValidationError({
                'tags': 'Должно быть отмечено не меньше 1 тега'
            })

        ingredient_ids = [ingredient['id'] for ingredient in ingredients]
        if len(ingredient_ids) != len(set(ingredient_ids)):
            raise serializers.ValidationError({
                'ingredients': 'Ингредиенты должны быть уникальными.'
            })

        if len(tags) != len(set(tags)):
            raise serializers.ValidationError({
                'tags': 'Теги должны быть уникальными.'
            })

        return data

    @transaction.atomic
    def add_ingredients_and_tags(self, tags, ingredients, recipe):
        """Добавление ингредиентов и тегов."""
        for tag in tags:
            recipe.tags.add(tag)
            recipe.save()
        IngredientRecipe.objects.bulk_create(
            [
                IngredientRecipe(
                    ingredient_id=ingredient['id'],
                    amount=ingredient['amount'],
                    recipe=recipe,
                )
                for ingredient in ingredients
            ]
        )
        return recipe

    @transaction.atomic
    def create(self, validated_data):
        """Метод создания нового объекта рецепта."""
        ingredients = validated_data.pop('ingredients')
        tags = validated_data.pop('tags')
        recipe = Recipe.objects.create(**validated_data)
        return self.add_ingredients_and_tags(
            tags, ingredients, recipe
        )

    @transaction.atomic
    def update(self, recipe, validated_data):
        """Обновление рецепта."""
        new_ingredients = validated_data.pop("ingredients")
        new_tags = validated_data.pop("tags")
        recipe.tags.clear()
        recipe.ingredients.clear()
        self.add_ingredients_and_tags(new_tags, new_ingredients, recipe)

        return super().update(recipe, validated_data)


class FavoriteShopingCartSerializer(serializers.ModelSerializer):
    """Абстрактная модель для Favorite и ShoppingCart."""

    class Meta:
        abstract = True

    def __init__(self, *args, **kwargs):
        """Получение модели в зависимости от сериализатора."""
        super().__init__(*args, **kwargs)
        self.model = self.Meta.model

    def validate(self, data):
        """Валидация для моделей списка покупок и избранного."""
        if self.model.objects.filter(
                user=data['user'],
                recipe=data['recipe']
        ).exists():
            raise serializers.ValidationError(
                f'{self.model._meta.verbose_name} уже добавлен'
            )
        return data

    def to_representation(self, instance):
        """Представление данных."""
        return RecipeShortSerializer(instance.recipe).data


class FavoriteSerializer(FavoriteShopingCartSerializer):
    """Сериализатор для избранного."""

    class Meta:
        model = Favorite
        fields = (
            'user',
            'recipe'
        )


class ShoppingCartSerializer(FavoriteShopingCartSerializer):
    """Сериализатор для списка покупок (корзины)."""

    class Meta:
        model = ShoppingCart
        fields = (
            'recipe',
            'user'
        )


class RecipeShortSerializer(serializers.ModelSerializer):
    """Сокращенное описание рецепта."""

    class Meta:
        model = Recipe
        fields = ('id', 'name', 'image', 'cooking_time')


class RecipeLinkSerializer(serializers.ModelSerializer):
    """Сериализатор для короткой ссылки."""

    recipe = serializers.PrimaryKeyRelatedField(
        queryset=Recipe.objects.all(),
        write_only=True)
    short_link = serializers.SerializerMethodField()

    class Meta:
        model = RecipeShortLink
        fields = ['recipe', 'short_link']

    def get_short_link(self, obj):
        request = self.context.get('request')
        host = request.get_host()
        return f"{request.scheme}://{host}/api/s/{obj.link}"

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['short-link'] = representation.pop('short_link')
        return representation
