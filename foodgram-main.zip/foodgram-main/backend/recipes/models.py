import random
import string

from django.core.validators import MinValueValidator
from django.db import models

from constants import (LENGHT_LINK, MAX_LENGHT_INGREDIENT, MAX_LENGHT_LINK,
                       MAX_LENGHT_NAME, MAX_LENGHT_TAG, MAX_LENGHT_UNIT,
                       MIN_VALUE)
from users.models import User


class Tag(models.Model):
    """Модель тегов."""

    name = models.CharField(
        'Название',
        max_length=MAX_LENGHT_TAG,
        unique=True)
    slug = models.SlugField(
        'Slug',
        max_length=MAX_LENGHT_TAG,
        unique=True)

    class Meta:
        ordering = ('name',)
        verbose_name = 'Тег'
        verbose_name_plural = 'Теги'

    def __str__(self):
        return self.name


class Ingredient(models.Model):
    """Модель ингредиентов."""

    name = models.CharField(
        'Название ингредиента',
        max_length=MAX_LENGHT_INGREDIENT,
        db_index=True)
    measurement_unit = models.CharField(
        'Единица измерения',
        max_length=MAX_LENGHT_UNIT)

    class Meta:
        constraints = (
            models.UniqueConstraint(
                fields=('name', 'measurement_unit'),
                name='unique_name_measurement_unit',
            ),
        )
        ordering = ('name',)
        verbose_name = 'Ингредиент'
        verbose_name_plural = 'Ингредиенты'

    def __str__(self):
        return f'{self.name} ({self.measurement_unit})'


class Recipe(models.Model):
    """Модель рецептов."""

    author = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        verbose_name='Автор',
        related_name='recipes')
    ingredients = models.ManyToManyField(
        Ingredient,
        through='IngredientRecipe',
        verbose_name='Ингредиенты',
        related_name='recipes')
    tags = models.ManyToManyField(
        Tag,
        through='TagRecipe',
        verbose_name='Теги',
        related_name='recipes')
    text = models.TextField('Текстовое описание')
    name = models.CharField(
        'Название рецепта',
        max_length=MAX_LENGHT_NAME,
        db_index=True)
    cooking_time = models.PositiveSmallIntegerField(
        'Время приготовления в минутах',
        validators=[MinValueValidator(MIN_VALUE)]
    )
    image = models.ImageField(
        'Картинка',
        upload_to='recipe/',
        blank=True)

    class Meta:
        ordering = ('name',)
        verbose_name = 'Рецепт'
        verbose_name_plural = 'Рецепты'

    def __str__(self):
        return self.name


class IngredientRecipe(models.Model):
    """Модель для связи рецепта и ингредиентов."""

    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        verbose_name='Рецепт')
    ingredient = models.ForeignKey(
        Ingredient,
        on_delete=models.CASCADE,
        verbose_name='Ингредиент')
    amount = models.PositiveSmallIntegerField(
        'Количество', validators=[MinValueValidator(MIN_VALUE)])

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['recipe', 'ingredient'],
                name='unique_recipe'
            )
        ]
        verbose_name = 'Ингредиент рецепта'
        verbose_name_plural = 'Ингредиенты рецепта'
        default_related_name = 'recipe_ingredients'

    def __str__(self):
        return (f'{self.recipe.name} содержит '
                f'{self.amount} {self.ingredient.name}')


class TagRecipe(models.Model):
    """Модель для связи тега и рецепта."""

    tag = models.ForeignKey(
        Tag,
        on_delete=models.CASCADE,
        verbose_name='Тег'
    )
    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        verbose_name='Рецепт'
    )

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['tag', 'recipe'],
                name='unique_tag_in_recipe'
            )
        ]


class FavoriteCartModel(models.Model):
    """Абстрактная модель для Favorite и ShoppingCart."""

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='%(class)ss',
        verbose_name='Пользователь',
    )
    recipe = models.ForeignKey(
        Recipe,
        on_delete=models.CASCADE,
        related_name='%(class)ss',
        verbose_name='Рецепт',
    )

    class Meta:
        abstract = True
        constraints = (
            models.UniqueConstraint(
                fields=('user', 'recipe'),
                name='unique_user_recipe_%(class)s',
            ),
        )
        ordering = ('recipe',)

    def __str__(self):
        return (
            f'{self.user.username} добавил {self.recipe.name} '
            f'в {self._meta.verbose_name}'
        )


class Favorite(FavoriteCartModel):
    """Модель избранного."""

    class Meta(FavoriteCartModel.Meta):
        verbose_name = 'Избранное'
        verbose_name_plural = 'Избранное'


class ShoppingCart(FavoriteCartModel):
    """Модель списка покупок (корзины с рецептами)."""

    class Meta(FavoriteCartModel.Meta):
        verbose_name = 'Список покупок'
        verbose_name_plural = 'Списки покупок'


class RecipeShortLink(models.Model):
    """Модель для коротких ссылок на рецепты."""

    recipe = models.ForeignKey(
        'Recipe',
        on_delete=models.CASCADE,
        related_name='recipe_link',
        verbose_name='Рецепт'
    )
    link = models.CharField(
        max_length=MAX_LENGHT_LINK,
        unique=True,
        blank=True,
        null=True,
        verbose_name='Ссылка',
    )

    class Meta:
        verbose_name = 'Короткая ссылка рецепта'
        verbose_name_plural = 'Короткие ссылки рецептов'
        constraints = [
            models.UniqueConstraint(
                fields=['recipe', 'link'],
                name='unique_recipe_link'
            )
        ]

    def save(self, *args, **kwargs):
        if not self.link:
            self.link = self.generate_unique_link()
        super().save(*args, **kwargs)

    def generate_unique_link(self):
        """Генерирует уникальную короткую ссылку."""
        characters = string.ascii_letters + string.digits
        while True:
            link = ''.join(random.choices(characters, k=LENGHT_LINK))
            if not RecipeShortLink.objects.filter(link=link).exists():
                return link
