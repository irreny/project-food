from rest_framework.pagination import PageNumberPagination

from constants import PAGE_LIMIT


class PageLimitPagination(PageNumberPagination):
    """Пагинация для списка объектов."""

    page_size_query_param = 'limit'
    page_size = PAGE_LIMIT
