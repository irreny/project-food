from django.db.models import Count, Sum
from django.http import FileResponse
from django.shortcuts import get_object_or_404
from django_filters.rest_framework import DjangoFilterBackend
from djoser.views import UserViewSet
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import (SAFE_METHODS, AllowAny,
                                        IsAuthenticated,
                                        IsAuthenticatedOrReadOnly)
from rest_framework.response import Response

from api.filters import IngredientFilter, RecipeFilter
from api.paginations import PageLimitPagination
from api.permissions import IsAuthorOrReadOnly
from recipes.models import (Favorite, Ingredient, IngredientRecipe, Recipe,
                            RecipeShortLink, ShoppingCart, Tag)
from recipes.serializers import (FavoriteSerializer, IngredientSerializer,
                                 RecipeGetSerializer, RecipeLinkSerializer,
                                 RecipePostSerializer, ShoppingCartSerializer,
                                 TagSerializer)
from users.models import Subscription, User
from users.serializers import (AvatarSerializer, SubscribeSerializer,
                               SubscriptionSerializer)


class TagViewSet(viewsets.ReadOnlyModelViewSet):
    """Вьюсет для создания объектов Tag."""

    queryset = Tag.objects.all()
    serializer_class = TagSerializer
    permission_classes = (AllowAny,)
    pagination_class = None


class IngredientViewSet(viewsets.ReadOnlyModelViewSet):
    """Вьюсет для ингредиентов."""

    queryset = Ingredient.objects.all()
    serializer_class = IngredientSerializer
    permission_classes = (AllowAny,)
    filter_backends = (DjangoFilterBackend,)
    filterset_class = IngredientFilter
    pagination_class = None


class RecipeViewSet(viewsets.ModelViewSet):
    """Вьюсет для рецептов."""

    queryset = Recipe.objects.all()
    permission_classes = (IsAuthorOrReadOnly, IsAuthenticatedOrReadOnly)
    pagination_class = PageLimitPagination
    filter_backends = (DjangoFilterBackend,)
    filterset_class = RecipeFilter

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

    def get_serializer_class(self):
        if self.request.method in SAFE_METHODS:
            return RecipeGetSerializer
        return RecipePostSerializer

    @staticmethod
    def add_to(serializer_class, request, pk):
        """Добавление рецептов."""
        recipe = get_object_or_404(Recipe, pk=pk)
        serializer = serializer_class(
            data={
                'user': request.user.id,
                'recipe': recipe.pk
            }
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED
        )

    @staticmethod
    def delete_from(model, request, pk):
        """Удаления рецептов."""
        recipe = get_object_or_404(Recipe, pk=pk)
        object = model.objects.filter(
            user=request.user,
            recipe=recipe.pk
        )
        if object.exists():
            object.delete()
            return Response(
                status=status.HTTP_204_NO_CONTENT
            )
        return Response(
            status=status.HTTP_400_BAD_REQUEST
        )

    @action(
        detail=True,
        methods=['post'],
        url_path='favorite'
    )
    def favorite(self, request, pk):
        """Добавление рецептов в избранное."""
        return self.add_to(FavoriteSerializer, request, pk)

    @favorite.mapping.delete
    def delete_favorite(self, request, pk):
        """Удаление рецептов из избранного."""
        return self.delete_from(Favorite, request, pk)

    @action(
        detail=True,
        methods=['post'],
        url_path='shopping_cart'
    )
    def shopping_cart(self, request, pk):
        """Добавление рецептов в список покупок."""
        return self.add_to(ShoppingCartSerializer, request, pk)

    @shopping_cart.mapping.delete
    def delete_shopping_cart(self, request, pk):
        """Удаление рецептов из списка покупок."""
        return self.delete_from(ShoppingCart, request, pk)

    @action(detail=True, methods=['get'], url_path='get-link')
    def get_short_link(self, request, *args, **kwargs):
        """Получение короткой ссылки."""
        recipe = self.get_object()
        recipe_link, _ = RecipeShortLink.objects.get_or_create(recipe=recipe)
        serializer = RecipeLinkSerializer(
            recipe_link,
            context={'request': request}
        )
        return Response(serializer.data, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='download_shopping_cart')
    def download_shopping_cart(self, request, *args, **kwargs):
        """Скачивание списка покупок."""
        user = request.user
        ingredients = IngredientRecipe.objects.filter(
            recipe__in=ShoppingCart.objects.filter(user=user).values('recipe')
        ).values(
            'ingredient__name', 'ingredient__measurement_unit'
        ).annotate(
            total_amount=Sum('amount')
        )
        shopping_list = self.ingredients_for_shoplist(ingredients)
        return FileResponse(shopping_list, content_type='text/plain')

    def ingredients_for_shoplist(self, ingredients):
        """Сбор ингредиентов в список для загрузки."""
        shopping_list = "Список покупок:\n\n"
        for item in ingredients:
            shopping_list += (
                f"{item['ingredient__name']}: "
                f"{item['total_amount']} "
                f"{item['ingredient__measurement_unit']}\n"
            )
        return ''.join(shopping_list)


class UserViewSet(UserViewSet):
    """Вьюсет для модели пользователя/подписок."""

    pagination_class = PageLimitPagination
    permission_classes = (AllowAny,)

    @action(
        detail=True,
        methods=['post'],
        permission_classes=(IsAuthenticated,),
        url_path='subscribe'
    )
    def subscribe(self, request, id):
        """Управление подписками."""
        following_user = get_object_or_404(User, pk=id)
        serializer = SubscribeSerializer(
            data={'user': request.user.id, 'following': following_user.id},
            context={'request': request}
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(
            serializer.data,
            status=status.HTTP_201_CREATED
        )

    @subscribe.mapping.delete
    def delete_subscribe(self, request, id):
        """Удаление подписок."""
        following_user = get_object_or_404(User, pk=id)
        subscription = Subscription.objects.filter(
            user=request.user,
            following=following_user.id
        )
        if subscription.exists():
            subscription.delete()
            return Response(
                status=status.HTTP_204_NO_CONTENT
            )
        return Response(
            status=status.HTTP_400_BAD_REQUEST
        )

    @action(
        detail=False,
        methods=['get'],
        permission_classes=(IsAuthenticated,),
        url_path='subscriptions'
    )
    def subscriptions(self, request):
        """Отображения подписок."""
        authors = User.objects.filter(
            following__user=request.user
        ).annotate(recipes_count=Count('recipes'))
        page = self.paginate_queryset(
            queryset=authors
        )
        serializer = SubscriptionSerializer(
            page,
            context={'request': request},
            many=True
        )
        return self.get_paginated_response(serializer.data)
        # authors = User.objects.filter(
        #     following__user=request.user
        # ).annotate(recipes_count=Count('recipes'))

        # page = self.paginate_queryset(authors)
        # if page is not None:
        #     serializer = SubscriptionSerializer(
        #         page, many=True, context={'request': request}
        #     )
        #     return self.get_paginated_response(serializer.data)

        # serializer = SubscriptionSerializer(
        #     authors,
        #     context={'request': request},
        #     many=True
        # )
        # return Response(serializer.data)

    @action(
        methods=['get'],
        detail=False,
        permission_classes=(IsAuthenticated,),
        url_name='me',
    )
    def me(self, request, *args, **kwargs):
        """Данные о себе."""
        return super().me(request, *args, **kwargs)

    @action(
        methods=['put'],
        detail=False,
        permission_classes=(IsAuthenticated,),
        url_path='me/avatar',
        url_name='me-avatar',
    )
    def avatar(self, request):
        """Добавление или удаление аватара."""
        serializer = self._change_avatar(request.data)
        return Response(serializer.data)

    @avatar.mapping.delete
    def delete_avatar(self, request):
        data = request.data
        if 'avatar' not in data:
            data = {'avatar': None}
        self._change_avatar(data)
        return Response(status=status.HTTP_204_NO_CONTENT)

    def _change_avatar(self, data):
        instance = self.get_instance()
        serializer = AvatarSerializer(instance, data=data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return serializer
