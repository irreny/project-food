import re

from django.core.exceptions import ValidationError

from constants import VALID_SYMBOLS, VALID_USERNAME


def validate_username(value):
    """Валидация для юзернейма."""
    forbidden_values = (VALID_USERNAME,)
    if value in forbidden_values:
        raise ValidationError(f'Недопустимое имя пользователя: {value}')

    forbidden_chars = re.sub(VALID_SYMBOLS, '', value)
    if forbidden_chars:
        raise ValidationError(
            'Недопустимые символы в имени пользователя:'
            .join(set(forbidden_chars))
        )

    return value
