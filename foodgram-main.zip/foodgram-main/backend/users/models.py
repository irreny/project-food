from django.contrib.auth.models import AbstractUser
from django.db import models

from constants import MAX_LENGHT_EMAIL, MAX_LENGHT_USER
from users.validators import validate_username


class User(AbstractUser):
    """Модель пользователя."""

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name', 'password']

    email = models.EmailField('Электронная почта',
                              unique=True,
                              max_length=MAX_LENGHT_EMAIL)
    username = models.CharField('Имя пользователя',
                                validators=(validate_username,),
                                max_length=MAX_LENGHT_USER,
                                unique=True)
    first_name = models.CharField('Имя', max_length=MAX_LENGHT_USER)
    last_name = models.CharField('Фамилия', max_length=MAX_LENGHT_USER)
    password = models.CharField('Пароль', max_length=MAX_LENGHT_USER)
    avatar = models.ImageField('Аватар',
                               upload_to='avatars/',
                               blank=True,
                               null=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['email', 'username'],
                name='unique_email_username'
            )
        ]
        ordering = ('username',)
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

    def __str__(self):
        return self.username


class Subscription(models.Model):
    """Класс подписки."""

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='follower',
        verbose_name='Подписчик'
    )
    following = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='following',
        verbose_name='Подписавшийся'
    )

    class Meta:
        verbose_name = 'Подписка'
        verbose_name_plural = 'Подписки'
        constraints = (
            models.UniqueConstraint(
                fields=('user', 'following', ),
                name='unique_follow'
            ),
        )

    def __str__(self):
        return f'{self.user} подписан на {self.following}'
