from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from users.models import Subscription, User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Админ-зона User."""

    list_display = ('id', 'username', 'first_name', 'last_name', 'email')
    search_fields = ('email', 'username')
    list_filter = ('email', 'username')
    empty_value_display = '-пусто-'


@admin.register(Subscription)
class SubscriberAdmin(admin.ModelAdmin):
    """Админ-зона подписок."""

    list_display = ('user', 'following')
    list_filter = ('following',)
    search_fields = ('user__username',)
