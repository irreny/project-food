# Проект Foodgram
[![.github/workflows/main.yml](https://github.com/irreny/foodgram/actions/workflows/main.yml/badge.svg)](https://github.com/irreny/foodgram/actions/workflows/main.yml)

Foodgram — это сервис, который помогает людям находить новые рецепты и делиться своими кулинарными идеями. Здесь можно публиковать свои рецепты, следить за рецептами любимых кулинаров, добавлять понравившиеся в избранное и даже формировать списки покупок с продуктами.

## Стек использованных технологий

+ Django 3.2
+ JWT
+ Python 3.9
+ DRF
+ PostgreSQL 13.10
+ Docker

## Как развернуть проект

1. Клонируйте репозиторий и перейдите в директорию проекта:

   ```bash
   git clone https://github.com/irreny/foodgram
   cd foodgram
   ```

2. Создайте и активируйте виртуальное окружение:

   ```bash
   python -m venv venv
   source venv/Scripts/activate  # для Windows
   source venv/bin/activate      # для Linux/MacOS
   ```

3. Установите зависимости:

   ```bash
   pip install -r requirements.txt
   ```

4. В корневой папке директории foodgram нужно создать файл с именем .env, в котором нужно указать следующие параметры:

- POSTGRES_USER=foodgram_user
- POSTGRES_PASSWORD=foodgram_password
- POSTGRES_DB=foodgram_db
- DB_NAME=foodgram
- DB_HOST=db
- DB_PORT=5432
- SECRET_KEY=somesecretkey
- ALLOWED_HOSTS=127.0.0.1,localhost,ваш_доменный_адрес,ваш_IP_адрес
- DEBUG=False

## Запуск проекта

1. Подключитесь к удаленному серверу.
```
ssh -i путь_до_файла_с_SSH_ключом/название_файла_с_SSH_ключом имя_пользователя@ip_адрес_сервера 
```
2. Cоздайте папку проекта foodgram и перейдите в неё:
```
mkdir foodgram
cd foodgram
```
3. Установите docker compose на сервер:
```
sudo apt update
sudo apt install curl
curl -fSL https://get.docker.com -o get-docker.sh
sudo sh ./get-docker.sh
sudo apt-get install docker-compose-plugin
```
4. Скопируйте в дирректорию проекта файлы docker-compose.production.yml и .env
```
scp -i path_to_SSH/SSH_name docker-compose.production.yml username@server_ip:/home/username/foodgram/docker-compose.production.yml
scp -i path_to_SSH/SSH_name .env username@server_ip:/home/username/foodgram/.env
```
5. Запустите docker compose в режиме демона:
```
sudo docker compose -f docker-compose.production.yml up -d
```
6. Выполните миграции, соберите статику бэкенда.
7. Отредактируйте конфиг Nginx на сервере, убедитесь в работоспособности и перезапустите Nginx.

## Настройка CI/CD

1. Файл workflow уже готов и находится в .github/workflows/main.yml
2. Заполните секреты в GitHub Actions.


## Автор

[irreny](https://github.com/irreny)
